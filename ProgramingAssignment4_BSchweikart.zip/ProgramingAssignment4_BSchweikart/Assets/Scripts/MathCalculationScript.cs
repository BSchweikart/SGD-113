﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MathCalculationScript : MonoBehaviour
{
    public int number1, number2;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyUp(KeyCode.UpArrow))
        {
            SubtractTwoNumbers();
        }

        if(Input.GetKeyDown(KeyCode.DownArrow))
        {
            MultiplayTwoNumbers();
        }
    }

    void SubtractTwoNumbers()
    {
        Debug.Log(number1 - number2);
    }

    void MultiplayTwoNumbers()
    {
        Debug.Log(number1 * number2);
    }
}
